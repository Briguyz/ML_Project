Files:
File 1 - movies_test.csv
File 2 - movies_train.csv
File 3 - svm_data-Copy.Rmd
File 4 - svm_model.Rmd
File 5 - svm_model2.Rmd
File 6 - svm_model3.Rmd

These files create three SVM classifier models:  
Model 1: Classifies movies into profitable/unprofitable based on production company and budget
Model 2: Classifies movies into profitable/unprofitable based on genre and budget
Model 3: Classifies movies into profitable/unprofitable based on actor company and budget

Data Input: 
Files 3 uses Files 1 and 2 to create SVM data. The e1071 svm function used in Files 3,4,5 requires a dataset with three columns as explemified below:
attribute 1	attribute 2	indicator 
10	         0.5	profit
20	         0.4	no.profit
10	         0.6	profit

The third column must be the indicator column. File 3 creates SVM data for Models 1, 2,and 3.


How to use these models to predict profit class:
1. Choose the appropriate File x (File 3, 4, or 5) according to which model you would like to use. 
3. Run File x to reproduce the model
4. Use predict(svmfit2, mydata) on the command line to obtain the model's predictions of your data-------------(see lines 225, 214, and 206 on Files 3, 4, and 5 respectively)
5. Type 'cm' on the command line to view the confusion matrix--------------------------------------------------(see lines 229, 218, and 210 on Files 3, 4, and 5 respectively)
6. Type 'accuracy', 'recall', and 'precision' on the command line to view accuracy, recall, and precision------(see lines 235-248, 223-237, 215-330 on Files 3, 4, and 5 respectively)
6. To observe a visual of the model's prediction on lines use plot(svmfit2,mydata)-----------------------------(see lines 219, 208, and 200 on Files 3, 4, and 5 respectively)
